function varargout = shuiyin123(varargin)
% SHUIYIN123 MATLAB code for shuiyin123.fig
%      SHUIYIN123, by itself, creates a new SHUIYIN123 or raises the existing
%      singleton*.
%
%      H = SHUIYIN123 returns the handle to a new SHUIYIN123 or the handle to
%      the existing singleton*.
%
%      SHUIYIN123('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SHUIYIN123.M with the given input arguments.
%
%      SHUIYIN123('Property','Value',...) creates a new SHUIYIN123 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before shuiyin123_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to shuiyin123_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help shuiyin123

% Last Modified by GUIDE v2.5 18-Mar-2016 22:27:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @shuiyin123_OpeningFcn, ...
                   'gui_OutputFcn',  @shuiyin123_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before shuiyin123 is made visible.
function shuiyin123_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to shuiyin123 (see VARARGIN)

% Choose default command line output for shuiyin123
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes shuiyin123 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = shuiyin123_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
 [name,path]=uigetfile({'*.jpg';'*.bmp';'gif'},'����ͼ��');
	if isequal(name,0)|isequal(path,0)
	    errordlg('���ˣ�û��ѡ���ļ���','����');
	    return;
	else
	    X=imread([path,name]);  %��ȡλ��
	    axes(handles.axes1);%axes��ʾ��ȡλ�ã�����ѡȡ��λ��Ϊaxes1��
        
	    imshow(X); %��ʾͼ��
        save('X');  %�������
	   guidata(hObject,handles) %���½ṹ�壻
       
    end
    msgbox('Q254965782')
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
 [name,path]=uigetfile({'*.jpg';'*.bmp';'gif'},'����ͼ��');
	if isequal(name,0)|isequal(path,0)
	    errordlg('���ˣ�û��ѡ���ļ���','����');
	    return;
	else
	    W=imread([path,name]);  %��ȡλ��
	    axes(handles.axes2);%axes��ʾ��ȡλ�ã�����ѡȡ��λ��Ϊaxes1��        
	    imshow(W); %��ʾͼ��
        save('W');  %�������
	   guidata(hObject,handles) %���½ṹ�壻
    end
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
axes(handles.axes4);
load('Y');
Z=Y;
prompt={'ѡ�񹥻�����:'};
	defans={'1����ת��2�����У�3������'};
	p=inputdlg(prompt,'ѡ�񹥻�����',2,defans);
	q=str2num(p{1});
switch q
    case 1
        prompt={'������ת�Ƕ�:'};
	defans={'10'};
	p=inputdlg(prompt,'������ת�Ƕ�',1,defans);
	q=str2num(p{1});
       Z = imrotate(Z,q,'crop');%��ת �Ƕȿ��Կ���
    case  2
       Z(128:256,256:384)=255;%���� �����Ƕ��ֵ���Կ���
    case  3
       Z=imnoise(Z,'gaussian');%������ ѡ����� help imnoise
end

imshow(Z,[]);
save('Z');

% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)

Z=double(Z);
[XCsource,XSsource]=wavedec2(Z,3,'db1');
low=XCsource(1:4096);
lowarray=reshape(XCsource(1:4096),64,64);
std=result;

for i = 1:64    
    ref1(i)=mean(lowarray(:,i));
    ref2(i)=mean(lowarray(i,:));
    for j=1:64
        pick(i,j,1)=xor(std(i,j,1),(lowarray(i,j)>ref1(i)));
        pick(i,j,2)=xor(std(i,j,2),(lowarray(i,j)>ref2(i)));        
    end

end
for i=1:4096
    ref3tmp=[XCsource(16381+4*i:16384+4*i)];
    ref3(i)=mean(ref3tmp);
    ref4tmp=[XCsource(32765+4*i:32768+4*i)];
    ref4(i)=mean(ref3tmp);
    ref5tmp=[XCsource(49149+4*i:49152+4*i)];
    ref5(i)=mean(ref5tmp);
    ref6tmp=[XCsource(65521+16*i:65536+16*i)];
    ref6(i)=mean(ref6tmp);
    ref7tmp=[XCsource(131057+16*i:131072+16*i)];
    ref7(i)=mean(ref7tmp);
    ref8tmp=[XCsource(196593+16*i:196608+16*i)];
    ref8(i)=mean(ref8tmp);
end

alaph3=double(mean(low)/mean(ref3));
alaph4=double(mean(low)/mean(ref4));
alaph5=double(mean(low)/mean(ref5));
alaph6=double(mean(low)/mean(ref6));
alaph7=double(mean(low)/mean(ref7));
alaph8=double(mean(low)/mean(ref8));

reref3=reshape(ref3,64,64);
reref4=reshape(ref4,64,64);
reref5=reshape(ref5,64,64);
reref6=reshape(ref6,64,64);
reref7=reshape(ref7,64,64);
reref8=reshape(ref8,64,64);

for i =1:64
    for j=1:64
        pick(i,j,3)=xor(std(i,j,3),(lowarray(i,j)>(alaph3*reref3(i,j))));
        pick(i,j,4)=xor(std(i,j,4),(lowarray(i,j)>(alaph4*reref4(i,j))));
        pick(i,j,5)=xor(std(i,j,5),(lowarray(i,j)>(alaph5*reref5(i,j))));
        pick(i,j,6)=xor(std(i,j,6),(lowarray(i,j)>(alaph6*reref6(i,j))));
        pick(i,j,7)=xor(std(i,j,7),(lowarray(i,j)>(alaph7*reref7(i,j))));
        pick(i,j,8)=xor(std(i,j,8),(lowarray(i,j)>(alaph8*reref8(i,j))));
    end
end

for i=1:64
    for j=1:64
        od=double(reshape(pick(i,j,:),1,8));
        dec(i,j)=bin2dec(char(od+48));
    end
end



imshow(dec,[]);


load('W');
origImg=W;
distImg=dec;

%load('distImg');
%If the input image is rgb, convert it to gray image
noOfDim = ndims(origImg);
if(noOfDim == 3)
    origImg = rgb2gray(origImg);
end

noOfDim = ndims(distImg);
if(noOfDim == 3)
    distImg = rgb2gray(distImg);
end

%Size Validation
origSiz = size(origImg);
distSiz = size(distImg);
sizErr = isequal(origSiz, distSiz);
if(sizErr == 0)
    disp('Error: Original Image & Distorted Image should be of same dimensions');
    return;
end

%Mean Square Error 

MSE = MeanSquareError(origImg, distImg);
%disp('Mean Square Error = ');
%disp(MSE);
set(handles.edit1,'string',MSE); 

%Peak Signal to Noise Ratio 
PSNR = PeakSignaltoNoiseRatio(origImg, distImg);
set(handles.edit2,'string',PSNR); 







% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)



% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
clc;   
clear all;
close(gcf)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
